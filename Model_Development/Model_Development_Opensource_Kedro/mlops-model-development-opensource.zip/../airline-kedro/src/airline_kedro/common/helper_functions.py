# helper functions to be used across many nodes/pipelines
import requests 
import json

# function to update fields in OpenPages
def updateFacts(field_key_name, field_value):
    # notice the openpages url, api key, and model name are hard coded as they wouldn't change for a given model
    op_url = " "
    op_api_key = " "
    op_model_name = " "
    
    key_value_lookup = {"model asset name": "MRG-Model:Model Asset Name"}
    
    field_name = key_value_lookup[field_key_name]
    
    def getModelResourceId(op_url, op_api_key, op_model_name):
        data = {
            "statement": "SELECT * FROM [Model] where [Model].[Name]={0}".format('\u0027' + op_model_name + '\u0027'),
            "skipCount": 0
        }
        r = requests.post("{0}/grc/api/query".format(op_url), headers={"Authorization": "Basic " + op_api_key},
                          json=data, verify=False)
        data = r.json()
        rows = data['rows']
        res = filter(lambda x: x['name'] == 'Resource ID', rows[0]['fields']['field'])
        return list(res)[0]['value']
    
    model_resource_id = getModelResourceId(op_url, op_api_key, op_model_name)
    
    resp = requests.get("{0}/grc/api/contents/{1}".format(op_url, model_resource_id),
                            headers={"Authorization": "Basic " + op_api_key}, verify=False)
    model_details = resp.json()

    def get_field_id(model, field_name):
        for field in model['fields']['field']:
            if "name" in field and field['name'] == field_name:
                 return field['id'];

    payload = {
        'name': model_details['name'],
        'fields': {
            'field': [{'dataType': 'STRING_TYPE',
                           'id': get_field_id(model_details, field_name),
                           'name': field_name,
                           'hasChanged': False,
                           'value': field_value
                           }]
            }
        }
    updated_model_details = requests.put("{0}/grc/api/contents/{1}".format(op_url, model_resource_id),
                                             headers={"Authorization": "Basic " + op_api_key}, json=payload,
                                             verify=False)
    return None #f"OpenPages field {field_name} has been updated with value: {field_value}"