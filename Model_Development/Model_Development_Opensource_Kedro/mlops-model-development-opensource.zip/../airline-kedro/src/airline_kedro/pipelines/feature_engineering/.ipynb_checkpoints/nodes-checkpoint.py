from typing import Any, Dict

import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler


def separate_features_label(data: pd.DataFrame) -> Dict[str, Any]:
    df = data
    X = df.drop('DELAYED', axis=1)
    y = df['DELAYED']

    return dict(train_x=X, train_y=y)

def separate_cat_num_columns() -> Dict[str, Any]:
    cat = ['MONTH',"DAY","DAY_OF_WEEK","ORIGIN_AIRPORT","DESTINATION_AIRPORT"]
    numeric = ['DEPARTURE_DELAY','TAXI_OUT',"DISTANCE"]

    return dict(categorical=cat, numeric=numeric)
