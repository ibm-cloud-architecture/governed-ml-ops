# Import packages
import logging
from typing import Any, Dict
import os
import io
import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline as skPipeline
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import cross_val_score,GridSearchCV
import sklearn
from project_lib import Project
from ibm_watson_machine_learning import APIClient
from airline_kedro.common.helper_functions import updateFacts
import requests, json, pickle


def cross_validation(preprocessor: object):
    
    # Define range of hyperparameters to test using Grid Search
    parameters = {'GBClassifier__learning_rate':[0.01,0.05,0.10], 'GBClassifier__n_estimators':[20,30,40]}
    
    # Define steps in modeling pipeline
    pipe_steps = skPipeline(steps=[('preprocessor', preprocessor),
                      ('GBClassifier', GradientBoostingClassifier())])
    
    # Use Grid Search to loop through hyperparameter values and determine the best model.  Here, 5-fold cross validation is being used and the model with highest accuracy is chosen.
    pipe = GridSearchCV(pipe_steps, parameters,scoring = "accuracy", cv=5)
    
    return pipe


def model_fit(pipe: object, train_x: pd.DataFrame, train_y: pd.DataFrame):
    
    X = train_x
    y = train_y
    
    
    # Fit the model.  The model with the optimal hyperparemeter values will be chosen here. 
    model = pipe.fit(X,y)
    
    return model

def save_model(model,train_x: pd.DataFrame):
    print("\n")
    project = Project.access()
    project_id = project.get_metadata()['metadata']['guid']    
    
    token = os.environ['USER_ACCESS_TOKEN']
    
    WML_CREDENTIALS = {
        "token": token,
        "instance_id": "wml_local",
        "url": os.environ['RUNTIME_ENV_APSX_URL'],
        "version": '4.0'
    }
    wml_client = APIClient(WML_CREDENTIALS)

    sw_spec_id = wml_client.software_specifications.get_id_by_name('default_py3.7')
    
    model_name = "airline-opensource-sklearn-model"
    model_library = "scikit-learn_0.23"
    model_props = {
        wml_client.repository.ModelMetaNames.NAME: model_name,
        wml_client.repository.ModelMetaNames.SOFTWARE_SPEC_UID: sw_spec_id,
        wml_client.repository.ModelMetaNames.TYPE: model_library}

    wml_client.set.default_project(project_id)
    
    saved_model_details = wml_client.repository.store_model(model=model, meta_props=model_props, training_data=None, training_target=None)
    
    print("\n Model is saved to the \'Models\' asset section of the project. \n")
    
    # In the steps below, we save model details (pipeline steps, hyperparameters, etc.) as a csv in the project, 
    #  which then gets published to catalog in a subsequent node.
    
    bestmodel = model.best_estimator_
    params_steps = bestmodel.get_params(deep=False)
    steps = params_steps['steps']
    
    params_steps_verbose = bestmodel.get_params(deep=True)
    params = {k:v for (k,v) in params_steps_verbose.items() if 'GBClassifier' in k}
    
    model_features = train_x.columns.tolist()
    
    data = [['Features',model_features],['Library',model_library],['Pipeline Steps', steps], ['Hyperparameters', params]]
  
    model_details_df = pd.DataFrame(data, columns = ['Model Information', 'Values'])
    
    project.save_data("model_details.csv",model_details_df.to_csv(index=False),overwrite=True)
    
    print("\n Model details are saved to the \'Data assets\' section of the project. \n")
    
    filename='airline-opensource-sklearn-model.pkl'
    pickle.dump(model, open(filename, 'wb'))
    cmd= 'mv ' + filename + ' ../project_data_assets/data_asset/'
    os.system(cmd)

    return project_id

    
def save_to_catalog(project_id):
    
    # Change the zip file name you would like or leave it as it is
    #  This is for saving the whole kedro pipeline as a zip file 
    #  and sharing purposes
    zip_file_name='mlops-model-development-opensource.zip'
    
    # Enter the catalog name that you created
    name_of_catalog='Model Assets'
    
    #---------
    
    # Packaging the whole kedro pipeline
    project = Project.access()
    command = 'zip -r ' + zip_file_name + ' ../airline-kedro -x ../airline-kedro/conf/local/**\\*'
    os.system(command)
    
    filename = os.getcwd() + '/' + zip_file_name
    with open(filename, 'rb') as z:
        data = io.BytesIO(z.read())
        project.save_data(zip_file_name, data, set_project_asset=True, overwrite=True)
    cmd2 = 'rm -rf ' + zip_file_name
    os.system(cmd2)
    
    # Variables
    project_id = project_id
    token = os.environ['USER_ACCESS_TOKEN']
    url = os.environ['RUNTIME_ENV_APSX_URL']
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer {}".format(token)
    }
    
    print("\n Getting Catalogs... \n")
    
    # Get Catalogs
    catalogs = requests.get("{0}/v2/catalogs".format(url), headers=headers, data="{}", verify=False).json().get('catalogs')
    catalog_dict = {}
    for i in range(0, len(catalogs)):
        catalog_name = catalogs[i]['entity']['name']
        catalog_id = catalogs[i]['metadata']['guid']
        catalog_dict[catalog_name] = catalog_id

    # Get Catalog Assets

    cat_payload = {"query": "*:*"}
    catalog_data = json.dumps(cat_payload, separators=(',', ': \n   '))
    catalog_id = catalog_dict[name_of_catalog]
    cat_assets = requests.post('{0}/v2/asset_types/asset/search?catalog_id={1}'.format(url, catalog_id), headers=headers, data=catalog_data, verify=False).json()
    results = cat_assets.get('results')
    
    print("\n Looking for data assets in the project... \n")
    
    # Look for Data Assets in the project
    assets = requests.post('{0}/v2/asset_types/data_asset/search?project_id={1}'.format(url, project_id), headers=headers, data=catalog_data, verify=False).json().get('results')
    
    print("\n Pushing zip file from data assets to the catalog ... \n")
    for i in range(0, len(assets)):
        asset_id = assets[i]['metadata']['asset_id']
        asset_name = assets[i]['metadata']['name']
        if(asset_name == zip_file_name):
            print("Asset name: ",asset_name, "\nAsset ID: ", asset_id)
            body = {"catalog_id":catalog_id}
            requests.post('{0}/v2/assets/{1}/publish?project_id={2}'.format(url, asset_id, project_id), headers=headers, json=body, verify=False).json()

    # Save the model to the catalog

    model_assets = requests.post('{0}/v2/asset_types/wml_model/search?project_id={1}'.format(url, project_id), headers=headers, data=catalog_data, verify=False).json().get('results')
    model_id = model_assets[0]['metadata']['asset_id']
    model_name = model_assets[0]['metadata']['name']
    body = {"catalog_id":catalog_id}
    requests.post('{0}/v2/assets/{1}/publish?project_id={2}'.format(url, model_id, project_id), headers=headers, json=body, verify=False).json()
    
    print("\n Done... \n")
