from kedro.pipeline import Pipeline, node
from airline_kedro.pipelines.feature_engineering.nodes import (
    separate_features_label, feature_eng,
    separate_cat_num_columns
)

def create_pipeline(**kwargs):
    return Pipeline(
        [
            node(
                func=separate_features_label,
                inputs="airline_train_flights",
                outputs=dict(
                    train_x="airline_train_x",
                    train_y="airline_train_y",
                ),
                name="separate_features_label",
            ),
            node(
                func=separate_cat_num_columns,
                inputs=None,
                outputs=dict(
                    categorical="categorical",
                    numeric="numerical",
                ),
                name="separate_cat_num_columns",
            ),
            node(
                func=feature_eng,
                inputs=["categorical", "numerical"],
                outputs="preprocessor",
                name="feature_eng",
            )

        ]
    )
