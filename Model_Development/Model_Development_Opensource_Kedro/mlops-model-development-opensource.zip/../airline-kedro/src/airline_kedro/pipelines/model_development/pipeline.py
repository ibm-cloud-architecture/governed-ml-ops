from kedro.pipeline import Pipeline, node
from airline_kedro.pipelines.model_development.nodes import (
    cross_validation, 
    model_fit, 
    save_model,
    save_to_catalog
)


    
def create_pipeline(**kwargs):
    return Pipeline(
        [   
             node(
                 func=cross_validation,
                 inputs=["preprocessor"],
                 outputs="pipe",
                 name="cross_validation",
             ),
             node(
                 func=model_fit,
                 inputs=["pipe", "airline_train_x", "airline_train_y"],
                 outputs="airline_model",
                 name="model_fit",
             ),
             node(
                 func=save_model,
                 inputs=["airline_model","airline_train_x"],
                 outputs="project_id",
                 name="save_model",
             ),
             node(
                 func=save_to_catalog,
                 inputs="project_id",
                 outputs=None,
                 name="save_to_catalog",
             )
         
        ]
    )